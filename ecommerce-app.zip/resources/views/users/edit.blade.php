@extends('layout')
@section('title', 'Edit User')
@section('content')
<main>
    <div class="container mt-3">
        <div class="row justify-content-center">

        <h1>Edit User</h1>
        <form action="{{route('users.update',['user'=>$user->id])}}" method="post">
            @csrf
            @method('PUT')
            <div class="col-md-3 mb-3">
                <label for="userName">Name</label>
                <input type="text" class="form-control" value="{{$user->name}}" name="name" id="">
                @error('name')
                <div class="text-danger">
                    {{$message}}
                </div>
                @enderror
            </div>
            <div class="col-md-3 mb-3">
                <label for="email">Email</label>
                <input type="email" class="form-control" value="{{$user->email}}" name="email" id="">
                @error('email')
                <div class="text-danger">
                    {{$message}}
                </div>
                @enderror
            </div>
            <div class="col-md-3 mb-3">
                <label for="password">Password</label>
                <input type="password" class="form-control" value="{{$user->password}}" name="password" id="">
                @error('password')
                <div class="text-danger">
                    {{$message}}
                </div>
                @enderror
            </div>
            <div class="col-md-3 mb-3">
                <label for="role">Role</label><br>
                <input type="text" class="form-control" value="{{$user->role}}" name="role" id="">
                @error('role')
                <div class="text-danger">
                    {{$message}}
                </div>
                @enderror
            </div>
            <div class="col-md-3 mb-3">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
</main>
@endsection
