@extends('layout')
@section('title', 'View User')
@section('content')
@include('flashmessages')
<main>
    <h1>View User</h1>
    @isset($users)
    @if(count($users) > 0 )
        <table class="table table-striped ">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Password</th>
                    <th scope="col">Role</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>

                    @foreach($users as $user)
                    <tr>
                        <td>{{$user['id']}}</td>
                        <td><a href="#"> {{$user['name']}}</a></td>
                        <td><a href="#"> {{$user['email']}}</a></td>
                        <td><a href="#"> {{$user['password']}}</a></td>
                        <td><a href="#"> {{$user['role']}}</a></td>
                        <td>
                            <form action="{{route('users.destroy', $user->id)}}"  method='post'>
                                @csrf
                                @method('DELETE')
                                <a href="{{route('users.edit', $user->id)}}"> Edit</a>|
                                <button>Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
            </tbody>
        </table>
        {{ $users->links() }}
    @else
    <h2>There are no data to display</h2>

    @endif
    @endisset
</main>
@endsection
