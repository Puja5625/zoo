@extends('layout')
@section('content')
<main class="mt-6">
    <h1>About Page</h1>
 </main>

@endsection
