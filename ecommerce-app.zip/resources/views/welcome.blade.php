@extends('layout')
@section('content')
<main class="mt-6">
    <h1>Home Page</h1>
 </main>

@endsection
