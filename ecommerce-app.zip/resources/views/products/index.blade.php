@extends('layout')
@section('title', 'View Products')
@section('content')
@include('flashmessages')
<main>
    <h1>View Products</h1>
    <a href="{{route('products.create')}}">
        <button class="btn btn-danger">Add Product</button>
    </a>
    @isset($products)
    @if(count($products) > 0 )
        <table class="table table-striped ">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">NAME</th>
                    <th scope="col">PRICE</th>
                    <th scope="col">QUANTITY</th>
                    <th scope="col">CATEGORY</th>
                    <th scope="col">Image</th>
                    <th scope="col">ACTION</th>
                </tr>
            </thead>
            <tbody>
                    @foreach($products as $product)
                    <tr>
                            <td>{{$product->id}}</td>
                            <td><a href="{{route('products.show', $product->id)}}">{{$product->name}}</a></td>
                            <td>{{$product->price}}</td>
                            <td>{{$product->quantity}}</td>
                            <?php $catName = App\Models\Category::find($product->category_id); ?>
                            <td>{{$catName->name}}</td>
                            <td><img src="images/{{$product->image}}" width="200" height="150" alt=""></td>
                            <td>
                                <a href="{{route('products.edit', $product->id)}}">Edit</a> |
                                <form action="{{route('products.destroy', $product->id)}}" method="post">
                                    @csrf
                                    @method('DELETE')

                                        <button  class="btn btn-danger">Delete</button>
                                </form></td>

                    </tr>
                    @endforeach

            </tbody>
        </table>
        {{$products->links()}}
    @else
    <h2>There are no data to display</h2>

    @endif
    @endisset
</main>
@endsection
