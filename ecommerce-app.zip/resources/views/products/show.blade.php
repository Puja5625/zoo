@extends('layout')
@section('title', 'Show Product')
@section('content')
<main>
    <h1>Detail Product</h1>

    <div class="card" style="width: 18rem;">
        <img src="../images/{{$product['image']}}" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title">{{$product['name']}}</h5>
            <p class="card-text"><b>Description:</b> {{$product['description']}} </p>
            <p class="card-text"><b>Price:</b>{{$product['price']}} </p>
            <p class="card-text"><b>Quantity:</b>{{$product['quantity']}} </p>
            <p class="card-text"><b>Category Id:</b>{{$product['category_id']}} </p>
            <a href="{{ route('products.index') }}" class="btn btn-primary">Go somewhere</a>
        </div>
</div>
</main>
@endsection
