@extends('layout')
@section('title', 'Add Category')
@section('content')
<main>
    <div class="container mt-5">
        <h1>Add Category</h1>
        <form action="{{route('categories.store')}}" method="post">
            @csrf
            <div class="col-md-3 mb-3">
                <label for="category">Category</label>
                <input type="text" value="{{ old('category') }}" name="category" id="">
                @error('category')
                    <div class="form-error">
                        {{$message}}
                    </div>
                @enderror


            </div>
            <div class="col-md-3 mb-3">
                <button type="submit" class="btn btn-primary">Add</button>
            </div>
        </form>
    </div>
</main>
@endsection
