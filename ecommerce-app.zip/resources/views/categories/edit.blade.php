@extends('layout')
@section('title', 'Update Category')
@section('content')
<main>
    <div class="container mt-5">
        <h1>Edit Category</h1>
        <form action="{{route('categories.update',['category'=>$category->id])}}" method="post">
            @csrf
            @method('PUT')
            <div class="col-md-3 mb-3">
                <label for="category">Category</label>
                <input type="text" value="{{ $category->name }}" name="category" id="">
                @error('category')
                    <div class="form-error">
                        {{$message}}
                    </div>
                @enderror


            </div>
            <div class="col-md-3 mb-3">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</main>
@endsection
