@extends('layout')
@section('title', 'View Categories')
@section('content')

<main>
    <h1>View Categories</h1>
    <a href="{{route('categories.create')}}">
        <button class="btn btn-danger">Add Category</button>
    </a>
    @if(count($categories) > 0 )
        <table class="table table-striped ">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>

                    @foreach($categories as $category)
                    <tr>
                        <td>{{$category['id']}}</td>
                        <td><a href="{{route('categories.show',['category'=>$category['id']])}}"> {{$category['name']}}</a></td>
                        <td><a href="{{route('categories.edit',['category'=>$category['id']])}}"> Edit</a>
                            <form action="{{ route('categories.destroy',$category->id) }}"  method='post'>
                                @csrf
                                @method('DELETE')
                                <button>Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
            </tbody>
        </table>
        {{ $categories->links() }}
    @else
    <h2>There are no data to display</h2>

    @endif
</main>
@endsection
