@extends('layout')
@section('title', 'View Categories')
@section('content')
<main>
    <h1>Detail Category</h1>
    {{$category['name']}}
</main>
@endsection
