@extends('layout')
@section('content')
<main class="mt-6">
    <h1>Contact Page</h1>
 </main>

@endsection
