<?php $__env->startSection('title', 'View Products'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main>
    <h1>View Products</h1>
    <a href="<?php echo e(route('products.create')); ?>">
        <button class="btn btn-danger">Add Product</button>
    </a>
    <?php if(isset($products)): ?>
    <?php if(count($products) > 0 ): ?>
        <table class="table table-striped ">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">NAME</th>
                    <th scope="col">PRICE</th>
                    <th scope="col">QUANTITY</th>
                    <th scope="col">CATEGORY</th>
                    <th scope="col">Image</th>
                    <th scope="col">ACTION</th>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><a href="<?php echo e(route('products.show', $product->id)); ?>"><?php echo e($product->name); ?></a></td>
                            <td><?php echo e($product->price); ?></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <?php $catName = App\Models\Category::find($product->category_id); ?>
                            <td><?php echo e($catName->name); ?></td>
                            <td><img src="images/<?php echo e($product->image); ?>" width="200" height="150" alt=""></td>
                            <td>
                                <a href="<?php echo e(route('products.edit', $product->id)); ?>">Edit</a> |
                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                        <button  class="btn btn-danger">Delete</button>
                                </form></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        <?php echo e($products->links()); ?>

    <?php else: ?>
    <h2>There are no data to display</h2>

    <?php endif; ?>
    <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Firstlaravelproject\ecommerce-app\resources\views/products/index.blade.php ENDPATH**/ ?>