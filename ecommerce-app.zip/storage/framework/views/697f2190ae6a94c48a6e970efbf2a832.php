<?php $__env->startSection('content'); ?>
<main class="mt-6">
    <h1>About Page</h1>
 </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Firstlaravelproject\ecommerce-app\resources\views/about.blade.php ENDPATH**/ ?>