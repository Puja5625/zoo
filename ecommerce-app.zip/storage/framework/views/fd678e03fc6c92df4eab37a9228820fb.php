<?php $__env->startSection('title', 'View Categories'); ?>
<?php $__env->startSection('content'); ?>

<main>
    <h1>View Categories</h1>
    <a href="<?php echo e(route('categories.create')); ?>">
        <button class="btn btn-danger">Add Category</button>
    </a>
    <?php if(count($categories) > 0 ): ?>
        <table class="table table-striped ">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category['id']); ?></td>
                        <td><a href="<?php echo e(route('categories.show',['category'=>$category['id']])); ?>"> <?php echo e($category['name']); ?></a></td>
                        <td><a href="<?php echo e(route('categories.edit',['category'=>$category['id']])); ?>"> Edit</a>
                            <form action="<?php echo e(route('categories.destroy',$category->id)); ?>"  method='post'>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button>Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($categories->links()); ?>

    <?php else: ?>
    <h2>There are no data to display</h2>

    <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Firstlaravelproject\ecommerce-app\resources\views/categories/index.blade.php ENDPATH**/ ?>