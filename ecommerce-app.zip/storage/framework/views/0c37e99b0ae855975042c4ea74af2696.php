<?php $__env->startSection('title', 'Show Product'); ?>
<?php $__env->startSection('content'); ?>
<main>
    <h1>Detail Product</h1>

    <div class="card" style="width: 18rem;">
        <img src="../images/<?php echo e($product['image']); ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($product['name']); ?></h5>
            <p class="card-text"><b>Description:</b> <?php echo e($product['description']); ?> </p>
            <p class="card-text"><b>Price:</b><?php echo e($product['price']); ?> </p>
            <p class="card-text"><b>Quantity:</b><?php echo e($product['quantity']); ?> </p>
            <p class="card-text"><b>Category Id:</b><?php echo e($product['category_id']); ?> </p>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Go somewhere</a>
        </div>
</div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Firstlaravelproject\ecommerce-app\resources\views/products/show.blade.php ENDPATH**/ ?>