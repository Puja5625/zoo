<?php $__env->startSection('title', 'View User'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main>
    <h1>View User</h1>
    <?php if(isset($users)): ?>
    <?php if(count($users) > 0 ): ?>
        <table class="table table-striped ">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Password</th>
                    <th scope="col">Role</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user['id']); ?></td>
                        <td><a href="#"> <?php echo e($user['name']); ?></a></td>
                        <td><a href="#"> <?php echo e($user['email']); ?></a></td>
                        <td><a href="#"> <?php echo e($user['password']); ?></a></td>
                        <td><a href="#"> <?php echo e($user['role']); ?></a></td>
                        <td>
                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>"  method='post'>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <a href="<?php echo e(route('users.edit', $user->id)); ?>"> Edit</a>|
                                <button>Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($users->links()); ?>

    <?php else: ?>
    <h2>There are no data to display</h2>

    <?php endif; ?>
    <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Firstlaravelproject\ecommerce-app\resources\views/users/index.blade.php ENDPATH**/ ?>