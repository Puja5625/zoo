<?php $__env->startSection('title', 'View Categories'); ?>
<?php $__env->startSection('content'); ?>
<main>
    <h1>Detail Category</h1>
    <?php echo e($category['name']); ?>

</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Firstlaravelproject\ecommerce-app\resources\views/categories/show.blade.php ENDPATH**/ ?>