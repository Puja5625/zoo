<?php $__env->startSection('title', 'Update Category'); ?>
<?php $__env->startSection('content'); ?>
<main>
    <div class="container mt-5">
        <h1>Edit Category</h1>
        <form action="<?php echo e(route('categories.update',['category'=>$category->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="col-md-3 mb-3">
                <label for="category">Category</label>
                <input type="text" value="<?php echo e($category->name); ?>" name="category" id="">
                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-error">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            </div>
            <div class="col-md-3 mb-3">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Firstlaravelproject\ecommerce-app\resources\views/categories/edit.blade.php ENDPATH**/ ?>