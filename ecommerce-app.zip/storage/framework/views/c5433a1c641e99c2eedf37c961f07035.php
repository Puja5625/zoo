<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>RIG - Home</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
        <style>
            body{
            background: linear-gradient(90deg, rgb(234, 171, 240) 0%, rgb(197, 205, 106) 35%, rgb(0, 3, 4) 100%);
          }
          .d1{
            background-color: lightblue;
            border-radius: 15px;
          }
          a,button{
            text-decoration: none;
          }
          .form-error{
            color:red;
          }
          ul li:hover{
            background-color: rgb(0, 255, 191);
            color:black;
          }
        </style>
    </head>
    <body class="font-sans antialiased dark:bg-black dark:text-white/50">
        <div class="container">

    <header class="p-3 text-bg-dark">
    <div class="container" >
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
            <li><a href="/" class="nav-link px-2 text-success">Home</a></li>
            <li><a href="about" class="nav-link px-2 text-white">About</a></li>
            <li><a href="contact" class="nav-link px-2 text-white">contact</a></li>
            <li><a href="<?php echo e(route('categories.index' )); ?>" class="nav-link px-2 text-white">Categories</a></li>
            <li><a href="<?php echo e(route('products.index' )); ?>" class="nav-link px-2 text-white">Product</a></li>
             <li><a href="<?php echo e(route('users.index' )); ?>" class="nav-link px-2 text-white">View user</a></li>
          </ul>

        <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
          <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search">
        </form>

        <div class="text-end">
            <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('auth.loginform')); ?>"><button type="button" class="btn btn-outline-light me-2">Login</button></a>
            <a href="<?php echo e(route('auth.registration')); ?>"><button type="button" class="btn btn-warning">Sign-up</button><a>
            <?php else: ?>
            <a href="<?php echo e(route('auth.logout')); ?>"><button type="button" class="btn btn-warning">Logout</button><a>
            <?php endif; ?>
          </div>
      </div>
    </div>
  </header>

<?php echo $__env->yieldContent('content'); ?>


                    <footer class="py-16 text-center text-sm text-black dark:text-white/70">
                        RIG &copy; 2024
                    </footer>
                </div>
            </div>
        </div>
    </div>
    </body>
</html>
<?php /**PATH C:\Firstlaravelproject\ecommerce-app\resources\views/layout.blade.php ENDPATH**/ ?>