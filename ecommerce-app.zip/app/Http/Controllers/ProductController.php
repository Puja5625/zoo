<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;
use App\Http\Requests\ProductFormRequest;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {   $products = Product::paginate(5);
        return view('products.index',['products'=>$products] );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::all();
        return view('products.create',['categories'=>$categories]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ProductFormRequest $request)
    {
        $request->validated();
        $product = new Product();
        $product->name  = $request->input('name');
        $product->description  = $request->input('description');
        $product->price  = $request->input('price');
        $product->quantity  = $request->input('quantity');
        $product->category_id = $request->input('category_id');
        $img_name = time(). '.' .$request->image->extension();//39749574.png
        $request->image->move(public_path('images'), $img_name);
        $product->image = $img_name;
        $product->save();
        return redirect()->route('products.index')->with('success','Successfully Insert!!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product)
    {
        //$record = Product::findOrFail($id);
        return view('products.show', ['product'=>$product]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        return view('products.edit',['product'=>$product, 'categories'=>Category::all()]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate(
            ['name'=>'required',
            'description' => 'required',
            'price' => 'required',
            'quantity' => 'required',
            'category_id' => 'required',
            'image' => 'required|image|mimes:jpeg,jpg,png,svg,gif|max:2048']
        );
        $product = Product::findOrFail($id);
        $product->name  = $request->input('name');
        $product->description  = $request->input('description');
        $product->price  = $request->input('price');
        $product->quantity  = $request->input('quantity');
        $product->category_id = $request->input('category_id');
        $img_name = time(). '.' .$request->image->extension();//39749574.png
        $request->image->move(public_path('images'), $img_name);
        $product->image = $img_name;
        $product->save();

        return redirect()->route('products.index')->with('success', 'Successfully Update!!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        $product->delete();
        return redirect()->route('products.index')->with('success', 'Successfully Delete!!');
    }
}
