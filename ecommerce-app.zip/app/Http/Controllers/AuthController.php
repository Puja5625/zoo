<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Product;
use App\Models\Category;

class AuthController extends Controller
{
    public function regirstration(){
        return view('auth.registration');
    }
    public function login(){
        return view('auth.loginform');
    }
    public function authenticate(Request $request){
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            $request->session()->regenerate();
            if($user->role == 'user'){
                $products = Product::all();
                return view('users.index',['products'=>$products]);
            }
            else if($user->role == 'admin'){
                $categories = Category::all();
                return view('categories.index',['categories'=>$categories]);
            }
        }


        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');
    }

    public function logout(Request $request){
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
