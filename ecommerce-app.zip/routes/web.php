<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
// use App\Http\Controllers\HomeController;

// Route::get('/', [HomeController::class, 'index']);
// Route::get('/about', [HomeController::class, 'about']);
// Route::get('/contact', [HomeController::class, 'contact']);

Route::get('/', function () {
    return view('welcome');
});
Route::get('/greeting', function () {
    return view('greeting',['name'=>'james']);
});
Route::get('/about', function(){
    return view('about');
});
Route::get('/contact', function(){
    return view('contact');
});
Route::get('/layout', function(){
    return view('layout');
});
Route::resource('/categories', CategoryController::class);
Route::resource('/products', ProductController::class);
Route::resource('/users', UserController::class);

Route::get('/register', [AuthController::class,'regirstration'])->name('auth.registration');
Route::get('/login', [AuthController::class,'login'])->name('auth.loginform');

Route::post('/post_register', [UserController::class, 'store'])->name('users.store');
Route::post('/post_login', [AuthController::class, 'authenticate'])->name('authenticate');

Route::get('/logout', [AuthController::class, 'logout'])->name('auth.logout');

Route::get('/view', [UserController::class,'index'])->name('users.index');

// Route::get('/users/{id}',function(string $id){
//     return 'User ' . $id;
// });
// Route::get('/posts/{post}/comment/{comment}',function(string $post,string $comment){
//     return 'post ' . $post. "and" ."comment".$comment;
// });
// Route::get('/user/{name?}', function (?string $name=null) {
//     return "Hello " . $name;
// });
// Route::get('/user/{name?}', function (?string $name='John') {
//     return "Hello " . $name;
// Route::get('/user/{name}', function (string $name) {
//     return "Hello " . $name;
// })->where('name', '[A-Za-z ]+');
// Route::get('/user/{id}', function (string $id) {
//     return "User id: " . $id;
// })->where('id', '[0-9]+');

// Route::get('/user/{id}/{name}', function (string $id, string $name) {
//     return "User id: " . $id . "<br> Name: " . $name;
// })->where(['id' => '[0-9]+', 'name' => '[a-z]+']);


// Route::get('/user/{id}/{name}', function (string $id, string $name) {
//     return "User id: " . $id . "<br> Name: " . $name;
// })->whereNumber('id')->whereAlpha('name');

// Route::get('/category/{category}', function (string $category) {
//     return $category;
// })->whereIn('category', ['movie', 'song', 'painting']);
